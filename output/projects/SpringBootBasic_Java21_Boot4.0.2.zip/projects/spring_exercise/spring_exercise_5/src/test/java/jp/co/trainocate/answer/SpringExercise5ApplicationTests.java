package jp.co.trainocate.answer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringExercise5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
